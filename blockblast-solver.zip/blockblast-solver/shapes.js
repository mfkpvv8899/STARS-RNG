const N = 8;

function rot(rows) {
  const h = rows.length, w = rows[0].length, out = [];
  for (let c = 0; c < w; c++) {
    let s = '';
    for (let r = h - 1; r >= 0; r--) s += rows[r][c];
    out.push(s);
  }
  return out;
}
function mirror(rows) { return rows.map(s => [...s].reverse().join('')); }
function variants(rows, withMirror) {
  const bases = withMirror ? [rows, mirror(rows)] : [rows];
  const out = [];
  for (const b of bases) { let cur = b; for (let i = 0; i < 4; i++) { out.push(cur); cur = rot(cur); } }
  return out;
}

const RAW = [['X']];
for (const n of [2, 3, 4, 5]) { RAW.push(['X'.repeat(n)]); RAW.push(Array(n).fill('X')); }
RAW.push(['XX', 'XX'], ['XXX', 'XXX', 'XXX'], ['XXX', 'XXX'], ['XX', 'XX', 'XX']);
RAW.push(...variants(['X.', 'XX']));
RAW.push(...variants(['X..', 'X..', 'XXX']));
RAW.push(...variants(['X.', 'X.', 'XX'], true));
RAW.push(...variants(['XXX', '.X.']));
RAW.push(...variants(['.XX', 'XX.'], true));
RAW.push(...variants(['XX', 'XX', 'X.'], true));

const SHAPES = [];
const _seen = new Set();
for (const rows of RAW) {
  const k = rows.join('|');
  if (_seen.has(k)) continue;
  _seen.add(k);
  const cells = [];
  rows.forEach((s, r) => [...s].forEach((ch, c) => { if (ch === 'X') cells.push([r, c]); }));
  SHAPES.push({ rows, cells, h: rows.length, w: rows[0].length });
}
