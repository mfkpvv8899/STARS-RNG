# Star RNG - APK com ranking e chat (Firebase)

## 1. Regras do Firestore (uma vez so)
No console do Firebase: Firestore Database > aba Regras.
Apague o que estiver la, cole o conteudo do arquivo firestore.rules e toque em Publicar.
(Se ainda nao criou o banco: Criar banco de dados, qualquer regiao, modo de producao.)

## 2. Gerar o APK pelo GitHub
1. Crie um repositorio novo no GitHub.
2. Envie TODOS os arquivos desta pasta (incluindo a pasta oculta .github).
3. Aba Actions > Build APK > Run workflow.
4. Em uns 5 a 8 min, baixe "star-rng-apk" em Artifacts.
5. Descompacte e mande o app-debug.apk para os amigos (permitir fontes desconhecidas).

Ranking e chat funcionam entre todos os celulares que tiverem o app e internet.
Sem internet o jogo continua funcionando, so o ranking e o chat ficam indisponiveis.
